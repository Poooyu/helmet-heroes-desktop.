HELMET HEROES DESKTOP - CLOUD BUILD

This project creates a Windows x64 portable Electron EXE. Electron includes Chromium, so it does not require Microsoft WebView2 Runtime.

BUILD USING GITHUB (NO NODE.JS INSTALL ON YOUR PHONE)
1. Sign in or create a GitHub account at https://github.com/.
2. Create a NEW repository. Name it helmet-heroes-desktop. Public or private is your choice.
3. Upload the contents of this folder to the repository, preserving the .github/workflows/build.yml path.
   IMPORTANT: GitHub's web uploader may hide dot-folders. If it does, create the workflow file using Add file > Create new file and enter this exact path:
   .github/workflows/build.yml
   Then paste the contents of build.yml from this ZIP.
4. Open the repository's Actions tab.
5. Select "Build Helmet Heroes Windows EXE" from the left side.
6. Press "Run workflow" and confirm.
7. Wait for the workflow to finish successfully.
8. Open the completed workflow run and scroll to Artifacts.
9. Download "Helmet-Heroes-Desktop-Windows-x64". Extract the downloaded ZIP to get the EXE.
10. Import that EXE into GameHub Lite.

APP DETAILS
- Opens https://therobby3.itch.io/helmet-heroes
- Online connection required.
- F11 toggles fullscreen; Ctrl+R reloads; Alt+F4 closes.
- Electron bundles Chromium and does not depend on WebView2 Runtime.
- GameHub Lite/Wine compatibility is not guaranteed; test before assuming it will run.
